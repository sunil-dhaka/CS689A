'''
List the 50 most frequent combinations of gender, case and number as a 3-tuple.
'''

import sys
import glob
import conllu

FEATS = ['Case','Gender','Number']

def read_conllu_file(filename):
    with open(filename, 'r', encoding='utf-8') as f:
        return conllu.parse(f.read())

def getGenderNumberCaseWordFreq(filename):

    data = read_conllu_file(filename)

    genderWordFreq = {} # {gender : freq}
    numberWordFreq = {} # {number : freq}
    caseWordFreq = {} # {case : freq}

    for sentence in data:
        for token in sentence:
            word = token['form']
            feats = token['feats']

            if feats is not None:
                for feat in feats:
                    if feat == FEATS[0]:
                        # for case
                        if word not in caseWordFreq:
                            caseWordFreq[word] = 0
                        caseWordFreq[word] += 1
                    
                    elif feat == FEATS[1]:
                        # for gender
                        if word not in genderWordFreq:
                            genderWordFreq[word] = 0
                        genderWordFreq[word] += 1
                    
                    elif feat == FEATS[2]:
                        # for number
                        if word not in numberWordFreq:
                            numberWordFreq[word] = 0
                        numberWordFreq[word] += 1

    return genderWordFreq, numberWordFreq, caseWordFreq

def getTop50MostFreqTuples(genderWordFreq, numberWordFreq, caseWordFreq):
    
    # sort the dicts
    genderWord = sorted(genderWordFreq.items(), key=lambda x: x[1], reverse=True)
    numberWord = sorted(numberWordFreq.items(), key=lambda x: x[1], reverse=True)
    caseWord = sorted(caseWordFreq.items(), key=lambda x: x[1], reverse=True)

    # get the top 50 most freq tuples
    top50Tuples = []
    for i in range(50):
        top50Tuples.append((genderWord[i][0], numberWord[i][0], caseWord[i][0]))

    return top50Tuples

def main():
    filenameList = glob.glob('data/*.conllu')
    genderWordFreq = {}
    numberWordFreq = {}
    caseWordFreq = {}
    for filename in filenameList:
        # get the freq
        tmp1, tmp2, tmp3 = getGenderNumberCaseWordFreq(filename)

        # add the freq
        for word in tmp1:
            if word not in genderWordFreq:
                genderWordFreq[word] = 0
            genderWordFreq[word] += tmp1[word]

        for word in tmp2:
            if word not in numberWordFreq:
                numberWordFreq[word] = 0
            numberWordFreq[word] += tmp2[word]
        
        for word in tmp3:
            if word not in caseWordFreq:
                caseWordFreq[word] = 0
            caseWordFreq[word] += tmp3[word]

    # get the top 50 most freq tuples
    top50Tuples = getTop50MostFreqTuples(genderWordFreq, numberWordFreq, caseWordFreq)

    # store the result in a file
    with open('top50Tuples.txt', 'w', encoding='utf-8') as f:
        for tuple in top50Tuples:
            f.write(str(tuple) + '\n')

if __name__ == '__main__':
    main()