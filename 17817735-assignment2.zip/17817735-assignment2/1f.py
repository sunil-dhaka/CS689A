'''
Find the directed POS tag tuples, i.e., hti , tj i. For each such 2-tuple, list the
frequencies separately for each relation R as well as total.
'''

import glob
import conllu

def readConlluFile(filename):
    with open(filename, 'r') as f:
        return conllu.parse(f.read())

def getDirectedPOSTagTuples(data):

    directedPOSTagTuples = {}

    for sentence in data:
        for token in sentence:
            if token['head'] != 0:
                headPOSTag = sentence[token['head'] - 1]['upostag']
                dependentPOSTag = token['upostag']
                directedPOSTagTuple = (headPOSTag, dependentPOSTag)
                if directedPOSTagTuple in directedPOSTagTuples:
                    directedPOSTagTuples[directedPOSTagTuple] += 1
                else:
                    directedPOSTagTuples[directedPOSTagTuple] = 1

    return directedPOSTagTuples
def getReations(data):
    relations = []
    for sentence in data:
        for token in sentence:
            if token['deprel'] not in relations:
                relations.append(token['deprel'])
    return relations

def relationSpecificDirectedPOSTagTuples(data, relation):
    
        directedPOSTagTuples = {}
    
        for sentence in data:
            for token in sentence:
                if token['deprel'] == relation and token['head'] != 0:
                    headPOSTag = sentence[token['head'] - 1]['upostag']
                    dependentPOSTag = token['upostag']
                    directedPOSTagTuple = (headPOSTag, dependentPOSTag)
                    if directedPOSTagTuple in directedPOSTagTuples:
                        directedPOSTagTuples[directedPOSTagTuple] += 1
                    else:
                        directedPOSTagTuples[directedPOSTagTuple] = 1
    
        return directedPOSTagTuples

def main():

    data = []
    for filename in glob.glob('data/*.conllu'):
        data.extend(readConlluFile(filename))

    directedPOSTagTuples = getDirectedPOSTagTuples(data)

    # store the frequencies in a file in descending order

    with open('directedPOSTagTuples.txt', 'w') as f:
        for key, value in sorted(directedPOSTagTuples.items(), key=lambda item: item[1], reverse=True):
            f.write('%s\t%s\n' % (key, value))

    relations = getReations(data)
    for relation in relations:
        directedPOSTagTuples = relationSpecificDirectedPOSTagTuples(data, relation)
        with open('output/relations/directedPOSTagTuples_%s.txt' % relation, 'w') as f:
            for key, value in sorted(directedPOSTagTuples.items(), key=lambda item: item[1], reverse=True):
                f.write('%s\t%s\n' % (key, value))


if __name__ == '__main__':
    main()