'''
(5 marks) Find the frequencies of POS tags of words
'''
import conllu

def getDataFromConllu(filename):
    # Read conllu file
    with open(filename, 'r', encoding='utf-8') as f: 
        data = conllu.parse(f.read())

    return data


def getPOSTagFreq(data):
    # Get the frequency of each POS tag
    posTagFreq = {}
    for sentence in data:
        for token in sentence:
            posTag = token['upostag']
            if posTag in posTagFreq:
                posTagFreq[posTag] += 1
            else:
                posTagFreq[posTag] = 1

    return posTagFreq

def getPOSTagFreqFromConllu(filename):
    # Read conllu file
    data = getDataFromConllu(filename)

    # Get the frequency of each POS tag
    posTagFreq = getPOSTagFreq(data)

    return posTagFreq

def getPOSTagFreqFromConlluList(filenameList):

    posTagFreq = {}
    for filename in filenameList:
        posTagFreqFromConllu = getPOSTagFreqFromConllu(filename)
        for posTag in posTagFreqFromConllu:
            if posTag in posTagFreq:
                posTagFreq[posTag] += posTagFreqFromConllu[posTag]
            else:
                posTagFreq[posTag] = posTagFreqFromConllu[posTag]

    return posTagFreq

def getPOSTagFreqFromConlluListAndSave(filenameList, filename):
    posTagFreq = getPOSTagFreqFromConlluList(filenameList)

    with open(filename, 'w', encoding='utf-8') as f:
        for posTag in posTagFreq:
            f.write(posTag + '\t' + str(posTagFreq[posTag])+'\n')


def main():
    import glob
    filenameList = glob.glob('data/*.conllu')
    getPOSTagFreqFromConlluListAndSave(filenameList, 'posTagFreq.txt')

main()