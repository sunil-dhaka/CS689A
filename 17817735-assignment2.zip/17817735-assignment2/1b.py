'''
 (5 marks) List the 50 most frequent words corresponding to each POS tag.
'''
import conllu

def getDataFromConllu(filename):
    # Read conllu file
    with open(filename, 'r', encoding='utf-8') as f: 
        data = conllu.parse(f.read())

    return data

def getWordPOSTagFreq(data):
    # Get the frequency of each POS tag
    wordPOSTagFreq = {}
    for sentence in data:
        for token in sentence:
            word = token['form']
            posTag = token['upostag']
            if (word, posTag) in wordPOSTagFreq:
                wordPOSTagFreq[(word, posTag)] += 1
            else:
                wordPOSTagFreq[(word, posTag)] = 1

    return wordPOSTagFreq

def getWordPOSTagFreqFromConllu(filename):
    # Read conllu file
    data = getDataFromConllu(filename)

    # Get the frequency of each POS tag
    wordPOSTagFreq = getWordPOSTagFreq(data)

    return wordPOSTagFreq


def getTop50WordsForPOSTag(filename):

    wordPOSTagFreq = getWordPOSTagFreqFromConllu(filename)

    top50WordsForPOSTag = {}
    for wordPOSTag in wordPOSTagFreq:
        if wordPOSTag[1] in top50WordsForPOSTag:
            top50WordsForPOSTag[wordPOSTag[1]].append((wordPOSTag[0], wordPOSTagFreq[wordPOSTag]))
        else:
            top50WordsForPOSTag[wordPOSTag[1]] = [(wordPOSTag[0], wordPOSTagFreq[wordPOSTag])]

    for posTag in top50WordsForPOSTag:
        top50WordsForPOSTag[posTag] = sorted(top50WordsForPOSTag[posTag], key=lambda x: x[1], reverse=True)[:50]

    return top50WordsForPOSTag

def getTop50WordsForPOSTagFromConlluList(filenameList):

    top50WordsForPOSTag = {}
    for filename in filenameList:
        top50WordsForPOSTagFromConllu = getTop50WordsForPOSTag(filename)
        for posTag in top50WordsForPOSTagFromConllu:
            if posTag in top50WordsForPOSTag:
                top50WordsForPOSTag[posTag] += top50WordsForPOSTagFromConllu[posTag]
            else:
                top50WordsForPOSTag[posTag] = top50WordsForPOSTagFromConllu[posTag]
    # only keep top 50 from each pos tag

    for posTag in top50WordsForPOSTag:
        top50WordsForPOSTag[posTag] = sorted(top50WordsForPOSTag[posTag], key=lambda x: x[1], reverse=True)[:50]

    return top50WordsForPOSTag


def getTop50WordsForPOSTagFromConlluListAndSave(filenameList, filename):

    top50WordsForPOSTag = getTop50WordsForPOSTagFromConlluList(filenameList)

    with open(filename, 'w', encoding='utf-8') as f:
        for posTag in top50WordsForPOSTag:
            f.write(posTag + '\n')
            for word in top50WordsForPOSTag[posTag]:
                f.write(word[0] + '\t' + str(word[1])+'\n')
            f.write('\n')


def main():

    import glob
    filenameList = glob.glob('data/*.conllu')
    getTop50WordsForPOSTagFromConlluListAndSave(filenameList, 'top50WordsForPOSTag.txt')

main()