--------------------------------------------------------------------------------------------
Plugins:

Softwares:
No software needed. Just python3 and pip3 installed.

Environments: python >= 3.10.0

Dependencies:
- tokenizers
- datasets
- conllu
--------------------------------------------------------------------------------------------
EVERYTHING IS DETAILED IN THIS README FILE. PLEASE READ IT BEFORE EVALUATING.
ALSO INDIVIDUAL SCRIPTS HAVE COMMENTS AND EXPLAINATION. PLEASE READ THEM BEFORE EVALUATING.
--------------------------------------------------------------------------------------------
Usage:
--------------------------------------------------------------------------------------------
How to run:
- You can run the code by running the following command:
    python3 <path_to_the_code_file>
- All of them are numbered. So you can run them in order.
--------------------------------------------------------------------------------------------
Specifics for each file to run:

- python 1a.py

- python 1b.py

- python 1c.py

- python 1d.py

- python 1e.py

- python 1f.py

- python 1g.py

- Que 2 notebook file can be evaluted from each cell. It is self explanatory.  

--------------------------------------------------------------------------------------------
THINGS WILL TAKE LOTS OF TIME TO RUN. PLEASE BE PATIENT. Specifically Que2. Training.
--------------------------------------------------------------------------------------------

OUTPUT:

- All the output files are in the output folder.

- The output files are named as folows:
    
    1a - 1a_output.txt
    1b - 1b_output.txt
    1c - 1c_output.txt
    1d - 1d_output.txt
    1e - 1e_output.txt
    1f - 1f_output.txt, relations/*
    1g - 1g_output.txt

- QUE2: Training for one set of hyperparameters takes around 7 hour on colab. And I tried three times; but connection got lost everytime after 1-2 hours of training.
--------------------------------------------------------------------------------------------
I KNOW IT IS LONG. BUT FOR COMPLETE INFORMATIVE DOCS I HAD TO INCLUDE IT.
HAVE FUN READING THIS.
--------------------------------------------------------------------------------------------