'''
Find the frequencies of POS tags corresponding to only head words.
'''

import glob
import conllu


def readConlluFile(filename):
    with open(filename, 'r') as f:
        return conllu.parse(f.read())

def getHeadPOSTagFreqs(data):

    headPOSTagFreqs = {}

    for sentence in data:
        for token in sentence:
            if token['head'] == 0:
                if token['upostag'] in headPOSTagFreqs:
                    headPOSTagFreqs[token['upostag']] += 1
                else:
                    headPOSTagFreqs[token['upostag']] = 1

    return headPOSTagFreqs

def main():

    data = []
    for filename in glob.glob('data/*.conllu'):
        data.extend(readConlluFile(filename))

    headPOSTagFreqs = getHeadPOSTagFreqs(data)

    
    # store the frequencies in a file in descending order

    with open('headPOSTagFreqs.txt', 'w') as f:
        for key, value in sorted(headPOSTagFreqs.items(), key=lambda item: item[1], reverse=True):
            f.write('%s\t%s\n' % (key, value))

if __name__ == '__main__':

    main()