'''
Find the directed POS tag tuples, i.e., hti , tj i. For each such 2-tuple, list the
frequencies separately for each relation R as well as total.
'''

import glob
import conllu

def readConlluFile(filename):
    with open(filename, 'r') as f:
        return conllu.parse(f.read())

def getReations(data):
    relations = []
    for sentence in data:
        for token in sentence:
            if token['deprel'] not in relations:
                relations.append(token['deprel'])
    return relations

def relationSpecificOverallPOSTagCount(data, relation):
    
        directedPOSTagTuples = 0
    
        for sentence in data:
            for token in sentence:
                if token['deprel'] == relation and token['head'] != 0:
                    directedPOSTagTuples += 1

        return directedPOSTagTuples
def main():

    data = []
    for filename in glob.glob('data/*.conllu'):
        data.extend(readConlluFile(filename))

    relations = getReations(data)
    directedPOSTagTuples={}
    for relation in relations:
        directedPOSTagTuples[relation] = relationSpecificOverallPOSTagCount(data, relation)

    # save the results
    with open('output/totalDependencyRelation.txt', 'w') as f:
        for relation in relations:
            f.write(relation + '\t' + str(directedPOSTagTuples[relation]) + '\n')



if __name__ == '__main__':
    main()