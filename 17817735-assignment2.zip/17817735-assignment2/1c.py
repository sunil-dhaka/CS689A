'''
Find the frequencies of gender, case and number of words separately
'''

import sys
import glob
import conllu
FEATS = ['Case','Gender','Number']

def read_conllu_file(filename):
    with open(filename, 'r', encoding='utf-8') as f:
        return conllu.parse(f.read())

def getFeatsFreq(filename):

    data = read_conllu_file(filename)

    featsFreq = {}

    for sentence in data:
        for token in sentence:
            feats = token['feats']
            
            if feats is not None:
                for feat in feats:
                    if feat in FEATS:
                        # count freq key-value pair wise
                        if feat not in featsFreq:
                            featsFreq[feat] = {}
                        if feats[feat] not in featsFreq[feat]:
                            featsFreq[feat][feats[feat]] = 0
                        featsFreq[feat][feats[feat]] += 1

    return featsFreq
# to do only case gender number wise
#                         if feat in featsFreq:
#                             featsFreq[feat] += 1
#                         else:
#                             featsFreq[feat] = 1

#     return featsFreq
                        
def main():

    
    filenameList = glob.glob('data/*.conllu')
    featsFreq = {}
    for filename in filenameList:
        featsFreqFromConllu = getFeatsFreq(filename)

        for feat in featsFreqFromConllu:
            if feat not in featsFreq:
                featsFreq[feat] = {}
            for value in featsFreqFromConllu[feat]:
                if value not in featsFreq[feat]:
                    featsFreq[feat][value] = 0
                featsFreq[feat][value] += featsFreqFromConllu[feat][value]

    # store the result in a file
    with open('featsFreq.txt', 'w', encoding='utf-8') as f:
        for feat in featsFreq:
            f.write(feat + '\n')

            for value in featsFreq[feat]:
                f.write('\t' + value + '\t' + str(featsFreq[feat][value]) + '\n')

if __name__ == '__main__':
    main()